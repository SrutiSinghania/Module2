package com.cg.capgemini.HelloWorld;


import org.junit.Assert;
import org.junit.Test;

public class CalculatorTest {
	@Test
	public void testAdd()
	{
		Calculator calc=new Calculator();
		int res=calc.add(2,4);
		Assert.assertEquals(6,res);
	}
	@Test
	public void testSubtract()
	{
		Calculator calc=new Calculator();
		int res=calc.subtract(10,4);
		Assert.assertEquals(6,res);
	}
}
