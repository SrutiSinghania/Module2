package com.cg.mpa.entities;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.validation.constraints.Pattern;

import org.hibernate.validator.constraints.Email;
import org.hibernate.validator.constraints.NotEmpty;

@Entity
@Table(name="purchasedetail")
public class PurchaseDetails {
	@Id
	@Column(name="purchase_id")
	@GeneratedValue(strategy=GenerationType.SEQUENCE,generator="seq")
	@SequenceGenerator(name="seq",sequenceName="seq_purchase_id",allocationSize=1)
	private Integer purchaseId;
	
	@NotEmpty(message="name is mandatory")
	@Pattern(regexp="[A-Z][a-zA-Z]{3,15}",message="name should contain only alphabets and size should be min 4 and max 15")
	@Column(name="cname")
	private String custName;
	
	@Column(name="phoneno")
	@NotEmpty(message="phone number is required")
	@Pattern(regexp="[0-9]{10}",message="Phone number should contain 10 digits only")
	private String phoneNo;
	
	@Column(name="mailid")
	@Email(message="enter a valid email id")
	private String emailId;
	
	@Column(name="purchasedate")
	@Pattern(regexp="[0-9]{2}-[A-Za-z]{3}-[0-9]{4}",message="date must be in dd-mon-year format")
	private String purchaseDate;
	
	@Column(name="mobile_id")
	private Integer mobileid;

	public PurchaseDetails() {
		super();
		// TODO Auto-generated constructor stub
	}

	public Integer getPurchaseId() {
		return purchaseId;
	}

	public void setPurchaseId(Integer purchaseId) {
		this.purchaseId = purchaseId;
	}

	public String getCustName() {
		return custName;
	}

	public void setCustName(String custName) {
		this.custName = custName;
	}

	public String getPhoneNo() {
		return phoneNo;
	}

	public void setPhoneNo(String phoneNo) {
		this.phoneNo = phoneNo;
	}

	public String getEmailId() {
		return emailId;
	}

	public void setEmailId(String emailId) {
		this.emailId = emailId;
	}

	public String getPurchaseDate() {
		return purchaseDate;
	}

	public void setPurchaseDate(String purchaseDate) {
		this.purchaseDate = purchaseDate;
	}

	public Integer getMobileid() {
		return mobileid;
	}

	public void setMobileid(Integer mobileid) {
		this.mobileid = mobileid;
	}

	@Override
	public String toString() {
		return "PurchaseDetails [purchaseId=" + purchaseId + ", custName="
				+ custName + ", phoneNo=" + phoneNo + ", emailId=" + emailId
				+ ", purchaseDate=" + purchaseDate + ", mobileid=" + mobileid
				+ "]";
	}
	
	
}
