package com.cg.emplist;

import org.springframework.beans.factory.xml.XmlBeanFactory;
import org.springframework.core.io.ClassPathResource;

import com.cg.emplist.SBU;

public class EmpListMain {
	public static void main(String[] args) {
		XmlBeanFactory factory=new XmlBeanFactory(new ClassPathResource("demo.xml"));
		SBU sbu=factory.getBean(SBU.class);
		System.out.println(sbu);
	}
}
