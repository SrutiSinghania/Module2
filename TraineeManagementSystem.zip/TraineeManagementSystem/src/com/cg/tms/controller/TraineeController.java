package com.cg.tms.controller;

import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import com.cg.tms.entities.Trainee;
import com.cg.tms.service.TraineeService;



@Controller
public class TraineeController {
	@Autowired
	TraineeService tser;
	@RequestMapping("start")
	public String showHome()
	{
		return "Login";
	}
	@RequestMapping("Validate")
	public String validation(@RequestParam("username")String username,@RequestParam("pwd")String pwd,Model model)
	{
		
		if(username.equals("Capgemini") && pwd.equals("corp123"))
			return "menu";
		else
			return "Login";
	}
	@RequestMapping("check")
	public String checking(@Valid @ModelAttribute("t")Trainee t,BindingResult res,Model model)
	{
		if(res.hasErrors())
		{
			model.addAttribute("t",t);
			return "insertDetails";
		}
		else
		{
			tser.insert(t);
			model.addAttribute("t",t);
			return "success";
		}
	}
	@RequestMapping("operation")
	public String showMenu(@RequestParam("ch")Integer ch,Model model)
	{
		Trainee t=new Trainee();
		model.addAttribute("t",t);
		switch(ch)
		{
		case 1: return "insertDetails";
		case 2: return "deleteTrainee";
		case 3: return "modifyDetails";
		case 4: return "retieveOneDetails";
		case 5: 
				List<Trainee> tlist=tser.getAllTrainee();
				model.addAttribute("tlist", tlist);
				return "Home";	
		}
		return null;
		//tser.delete(id);
		//return "deleteTrainee";
	}
	@RequestMapping("deleteT")
	public String del(@RequestParam("id")int id,Model model)
	{
			tser.delete(id);
			model.addAttribute("id",id);
			return "success";
	}
	@RequestMapping("Retrieve1")
	public String rOne(@RequestParam("id")int id,Model model)
	{
			model.addAttribute("id",tser.retreiveOne(id));
			return "rone";
	}
	@RequestMapping("modT")
	public String modDetails(@RequestParam("id")int id,Model model)
	{
			Trainee t=new Trainee();
			t.setTraineeId(id);
			model.addAttribute("t",t);
			return "insmod";
	}
	@RequestMapping("Mod")
	public String modifying(@Valid @ModelAttribute("t")Trainee t,BindingResult res,Model model)
	{
		if(res.hasErrors())
		{
			model.addAttribute("t",t);
			return "insmod";
		}
		else
		{
			tser.modify(t);
			model.addAttribute("t",t);
			return "success";
		}
	}
}
