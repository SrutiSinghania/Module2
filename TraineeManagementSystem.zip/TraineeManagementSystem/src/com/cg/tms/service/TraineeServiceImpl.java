package com.cg.tms.service;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.tms.dao.TraineeDao;
import com.cg.tms.entities.Trainee;

@Service
@Transactional
public class TraineeServiceImpl implements TraineeService{
	@Autowired
	TraineeDao tdao;
	@Override
	public void insert(Trainee t) {
		tdao.insert(t);
		
	}
	@Override
	public void delete(int id) {
		tdao.delete(id);
		
	}
	@Override
	public Trainee retreiveOne(int id) {
		// TODO Auto-generated method stub
		return tdao.retreiveOne(id);
	}
	@Override
	public List<Trainee> getAllTrainee() {
		// TODO Auto-generated method stub
		return tdao.getAllTrainee();
	}
	@Override
	public void modify(Trainee t) {
		// TODO Auto-generated method stub
		tdao.modify(t);
	}

}
