package com.cg.tms.service;

import java.util.List;

import com.cg.tms.entities.Trainee;

public interface TraineeService {
	public void insert(Trainee t);
	public void delete(int id);
	public Trainee retreiveOne(int id);
	public List<Trainee> getAllTrainee();
	public void modify(Trainee t);
}
