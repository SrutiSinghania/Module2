package com.cg.tms.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;

import org.springframework.stereotype.Repository;

import com.cg.tms.entities.Trainee;
@Repository
public class TraineeDaoImpl implements TraineeDao{
	@PersistenceContext
	private EntityManager em;
	@Override
	public void insert(Trainee t) {
		em.persist(t);
		
	}
	@Override
	public void delete(int id) {
		Trainee t=em.find(Trainee.class,id);
		em.remove(t);
	}
	@Override
	public Trainee retreiveOne(int id) {
		// TODO Auto-generated method stub
		return em.find(Trainee.class,id);
	}
	@Override
	public List<Trainee> getAllTrainee() {
		String jpql="select t from Trainee t";
		TypedQuery<Trainee> query=em.createQuery(jpql,Trainee.class);
		return query.getResultList();
	}
	@Override
	public void modify(Trainee t) {
		// TODO Auto-generated method stub
		em.merge(t);
	}

}
