package com.cg.demo;

import java.util.List;

public class Employee {
	private int empId;
	private String ename;
	private List<Address> address;
	public List<Address> getAddress() {
		return address;
	}
	public void setAddress(List<Address> address) {
		this.address = address;
	}
	public Employee() {
		super();
		// TODO Auto-generated constructor stub
	}
	public int getEmpId() {
		return empId;
	}
	public void setEmpId(int empId) {
		this.empId = empId;
	}
	public String getEname() {
		return ename;
	}
	public void setEname(String ename) {
		this.ename = ename;
	}
	@Override
	public String toString() {
		return "Employee [empId=" + empId + ", ename=" + ename + ", address="
				+ address + "]";
	}
	public Employee(int empId, String ename, List<Address> address) {
		super();
		this.empId = empId;
		this.ename = ename;
		this.address = address;
	}
	
	
}
