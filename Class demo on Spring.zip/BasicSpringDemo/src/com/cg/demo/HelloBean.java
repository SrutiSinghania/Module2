package com.cg.demo;

public class HelloBean {
	public String helloWorld()
	{
		return "Welocme to Spring";
	}
}
