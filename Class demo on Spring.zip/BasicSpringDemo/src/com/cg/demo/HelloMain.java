package com.cg.demo;

import org.springframework.beans.factory.xml.XmlBeanFactory;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.springframework.core.io.ClassPathResource;

public class HelloMain {

	public static void main(String[] args) {
		ClassPathXmlApplicationContext factory=new ClassPathXmlApplicationContext("demo.xml");
		HelloBean bean=(HelloBean) factory.getBean("hBean");
		System.out.println(bean.helloWorld());
		
		//Address myAdd = (Address) factory.getBean("address");
		//System.out.println(myAdd);
		
		Employee emp=factory.getBean(Employee.class);
		System.out.println(emp);
	}

}
