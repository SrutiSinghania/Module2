package com.cg.ui;

import java.util.Scanner;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

import com.cg.entities.Authors;

public class AuthorMain {
	static Authors auth;
	static Scanner sc;
	static EntityManager em;
	public static void main(String[] args)
	{
		EntityManagerFactory emf=Persistence.createEntityManagerFactory("JPA-PU");
		em=emf.createEntityManager();
		//Authors auth=em.find(Authors.class,1001);
		//System.out.println(mob);
		sc=new Scanner(System.in);
		auth=new Authors();
		int choice;
		while(true)
		{
			System.out.println("1)insert 2)select 3)delete 4)update \n Press any other key to exit");
			System.out.println("Enter your choice:");
			choice=sc.nextInt();
			switch(choice)
			{
			case 1:insertData();
			break;
			case 2:display();
			break;
			case 3:delete();
			break;
			case 4:update();
			break;
			default:
				System.exit(0);
			}
		}
	}
		public static void insertData()
		{
			System.out.println("Enter First Name:");
			auth.setFirstName(sc.next());
			System.out.println("Enter Middle Name:");
			auth.setMiddleName(sc.next());
			System.out.println("Enter Last Name:");
			auth.setLastName(sc.next());
			System.out.println("Enter Phone Number:");
			auth.setPhoneNo(sc.nextLong());
			em.getTransaction().begin();
			em.persist(auth);
			em.getTransaction().commit();
			System.out.println("Author details inserted");
		}
		public static void display()
		{
			System.out.println("Enter author id whose information you want to view:");
			int id=sc.nextInt();
			auth=em.find(Authors.class,id);
			System.out.println(auth);
		}
		public static void delete()
		{
			System.out.println("Enter author id to be deleted:");
			int id=sc.nextInt();
			auth=em.find(Authors.class,id);
			//System.out.println(auth);
			em.getTransaction().begin();
			em.remove(auth);
			em.getTransaction().commit();
			System.out.println("Author details deleted");
		}
		public static void update()
		{
			System.out.println("Enter author id to be updated:");
			int id=sc.nextInt();
			auth=em.find(Authors.class,id);
			System.out.println("which detail do you want to update:1)firstName 2)MiddleName 3)LastName 4)phone  number");
			int choice=sc.nextInt();
			switch(choice)
			{
			case 1:
				System.out.println("Enter the new first name:");
				String newName=sc.next();
				auth.setFirstName(newName);
			break;
			case 2:
				System.out.println("Enter the new middle name:");
				String newMName=sc.next();
				auth.setMiddleName(newMName);
			break;
			case 3:
				System.out.println("Enter the new middle name:");
				String newLName=sc.next();
				auth.setLastName(newLName);
			break;
			case 4:
				System.out.println("Enter the new Phone number:");
				long newNum=sc.nextLong();
				auth.setPhoneNo(newNum);
			break;
			}
			
			//System.out.println(auth);
			em.getTransaction().begin();
			em.merge(auth);
			em.getTransaction().commit();
			System.out.println("Author details updated");
		}
}
